cometd-javascript-bower
=======================

Bower-installable distribution of the cometd javascript libraries (from https://github.com/cometd/cometd).
