# Change Log

All notable changes to this project are documented in this file.


## 0.0.6 - 2014-09-18

### Changed

* __BREAKING CHANGE__: Initial watch is done with scope.$watch instead of scope.$watchCollection.
